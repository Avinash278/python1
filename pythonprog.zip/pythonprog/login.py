from flask import Flask, render_template, request, json
import MySQLdb

app = Flask(__name__)
db = MySQLdb.connect(host="localhost", user="root", passwd="", db="userdb")


@app.route("/")
def login():
    return render_template("login.html")


@app.route("/connection", methods=['POST'])
def connection():
	num1 = request.form['Number1']
	num2 = request.form['Number2']
	cal = num1 + num2
    return json.dumps({'status': 'OK', 'n1': num1, 'n2': num2})


if __name__ == "__main__":
    app.run(debug=True)
